local spawn_position_x = 227
local spawn_position_y = -85
local one_hitpoint = 0.04

function OnWorldPreUpdate()
  local player_entity_id = (EntityGetWithTag("player_unit") or {})[1]
  if player_entity_id == nil then
    return
  end

  local player_damage_model_component_id = EntityGetFirstComponent(player_entity_id, "DamageModelComponent")
  if player_damage_model_component_id == nil then
    return
  end

  ComponentSetValue(player_damage_model_component_id, "wait_for_kill_flag_on_death", "1") -- HACK: disables death / game over screen

  local health = tonumber(ComponentGetValue(player_damage_model_component_id, "hp"))
  if health < one_hitpoint then
    local max_health = tonumber(ComponentGetValue(player_damage_model_component_id, "max_hp"))
    EntitySetTransform(player_entity_id, spawn_position_x, spawn_position_y) -- TODO: place player at the starting position of the level they're on
    ComponentSetValue(player_damage_model_component_id, "hp", max_health)
    GameRegenItemActionsInPlayer(player_entity_id)
    GamePrintImportant("Respawned", "You were killed")
  end
end
